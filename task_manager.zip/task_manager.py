import json
import os

tasks_file = "tasks.json"

def load_tasks():
    if os.path.exists(tasks_file):
        with open(tasks_file, "r", encoding="utf-8") as file:
            return json.load(file)
    return []

def save_tasks(tasks):
    with open(tasks_file, "w", encoding="utf-8") as file:
        json.dump(tasks, file, indent=4)

def add_task(task):
    tasks = load_tasks()
    tasks.append(task)
    save_tasks(tasks)
    print(f"任务 '{task}' 已添加！")

def list_tasks():
    tasks = load_tasks()
    if not tasks:
        print("暂无任务！")
    else:
        print("当前任务列表:")
        for idx, task in enumerate(tasks, start=1):
            print(f"{idx}. {task}")

def delete_task(index):
    tasks = load_tasks()
    if 0 < index <= len(tasks):
        removed = tasks.pop(index - 1)
        save_tasks(tasks)
        print(f"任务 '{removed}' 已删除！")
    else:
        print("无效的任务编号！")

def main():
    while True:
        print("\n任务管理器:")
        print("1. 添加任务")
        print("2. 查看任务")
        print("3. 删除任务")
        print("4. 退出")
        
        choice = input("请选择操作 (1/2/3/4): ")
        if choice == "1":
            task = input("请输入任务内容: ")
            add_task(task)
        elif choice == "2":
            list_tasks()
        elif choice == "3":
            list_tasks()
            try:
                index = int(input("请输入要删除的任务编号: "))
                delete_task(index)
            except ValueError:
                print("请输入有效的数字！")
        elif choice == "4":
            print("再见！")
            break
        else:
            print("无效选择，请重新输入！")

if __name__ == "__main__":
    main()
